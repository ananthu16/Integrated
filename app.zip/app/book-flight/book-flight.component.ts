import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { BookFlightService } from "./book-flight.service";
/* Import the required modules here */ 


@Component({
  selector: 'app-book-flight',
  templateUrl: './book-flight.component.html',
  styleUrls: ['./book-flight.component.css'],
  providers: [BookFlightService]
})
export class BookFlightComponent implements OnInit {
  flightDetails
  errorMessage: String;
  successMessage: String;
  bookingForm: FormGroup;
  isDisabled = true;

  /* Inject the required dependencies here */
  constructor(private bookflight:BookFlightService,private formbuilder:FormBuilder) { }

  ngOnInit() { }

  showForm(flight) {
    // populate flightDetails with flight
    //code the bookingForm with all mentioned validations
    this.flightDetails = flight
    this.isDisabled = false
    this.bookingForm = 
  }

  book() {
    // implement the book method by invoking the bookFlight method of BookFlightService
    // and correspondingly populate errorMessage and successMessage 
  }

  validateCustomerId(c: FormControl) {
    // implement a custom validator to validate customerId and populate customerIdErr object with message 

  }
}



