import { Component, OnInit } from '@angular/core';
import { ViewDetailsService } from "./view-details.service";
import { FlightBooking } from '../shared/FlightBooking';
import { Flights } from '../shared/Flight';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.css'],
  providers: [ViewDetailsService]
})
export class ViewDetailsComponent implements OnInit {
  custId: string
  flightId: string
  bookings: Flights[] = []
  flightDetails: FlightBooking[];

  errorMessage: String;
  flights: Flights[];

  /* Inject the required dependencies here */ 
  constructor() { }

  ngOnInit() { }


  viewAllBookings() {
    // implement the viewAllBookings method by invoking the view method of ViewDetailsService
    // and correspondingly populate flightDetails and errorMessage 
  }

}