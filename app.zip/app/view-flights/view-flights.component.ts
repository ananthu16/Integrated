import { Component, OnInit, Output, EventEmitter } from '@angular/core';
/* Import the required modules here */  
import { ViewDetailsService } from '../view-details/view-details.service';

@Component({
  selector: 'app-view-flights',
  templateUrl: './view-flights.component.html',
  styleUrls: ['./view-flights.component.css']
})

export class ViewFlightsComponent implements OnInit {
  flightDetails;

  @Output() flightToEmit = new EventEmitter();

  imageUrl = ["../../assets/a1.jpg", "../../assets/a2.jpg", "../../assets/a3.jpg"];
  errorMessage = null;

  /* Inject the required dependency here */
  constructor(private view:ViewDetailsService) { }
  
  ngOnInit() { 
    this.getAllFlights()
  }

  getAllFlights() {
    // implement the getAllFlights method by invoking the view method of ViewDetailsService
    // and correspondingly populate flightDetails and errorMessage 
    this.view.view().subscribe((response)=>{this.flightDetails=response},(error)=>{this.errorMessage=error.error.message})
  }

  sendFlightData(flight) {
    // emit the flight object using the flightToEmit event
    this.flightToEmit.emit(flight)

  }

}
