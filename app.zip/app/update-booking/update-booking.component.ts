import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
/* Import the required modules here */ 

@Component({
  selector: 'app-update-booking',
  templateUrl: './update-booking.component.html',
  styleUrls: ['./update-booking.component.css']
})
export class UpdateBookingComponent implements OnInit {

  bookingId: number;
  flightId: string;
  successMessage: string;
  errorMessage: string;
  updateBookingForm: FormGroup;

  /* Inject the required dependencies here */
  constructor() { }
  
  ngOnInit() {
    // Fetch the values from route parameters
    // code the updateBookingForm with mentioned requirements
  }

  updateBooking() {
    // Implement the updateBooking method by invoking the updateBooking method of UpdateBookingService
    // and correspondingly populate errorMessage and successMessage 
  }
}

