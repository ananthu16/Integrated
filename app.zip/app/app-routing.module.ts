import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewFlightsComponent } from './view-flights/view-flights.component';
import { BookingsComponent } from './bookings/bookings.component';
import { BookFlightComponent } from './book-flight/book-flight.component';

/* Import the necessary modules here */ 

/* Create the necessary routes here */
export const routes: Routes = [
  {path:'book',component:BookFlightComponent},
  // {path:'book',component:ViewFlightsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
